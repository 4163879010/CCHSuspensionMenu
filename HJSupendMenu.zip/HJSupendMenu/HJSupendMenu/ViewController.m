//
//  ViewController.m
//  HJSupendMenu
//
//  Created by 陈灿和 on 2017/12/7.
//  Copyright © 2017年 陈灿和. All rights reserved.
//

#import "ViewController.h"
#import "CCHSuspensionMenu.h"
@interface ViewController () <CCHSuspensionMenuDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    CCHSuspensionMenu *menu = [[CCHSuspensionMenu alloc] initWithPrimaryImage:@"111" menuSize:54 menuNum:4];
    [self.view addSubview:menu];
    menu.images = @[@"222", @"333", @"444", @"555"];
    menu.titles = @[@"222", @"333", @"444", @"555"];
    menu.delegate = self;
    
}

- (void)CCHSuspensionMenu:(CCHSuspensionMenu *)menu selectedItemForIndex:(NSInteger)index {
    NSLog(@"selected index : %ld",(long)index);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
