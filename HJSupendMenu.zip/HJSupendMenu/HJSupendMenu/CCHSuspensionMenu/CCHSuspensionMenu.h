//
//  CCHSuspensionMenu.h
//  HJSupendMenu
//
//  Created by 陈灿和 on 2017/12/7.
//  Copyright © 2017年 陈灿和. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CCHSuspensionMenu;
@protocol CCHSuspensionMenuDelegate <NSObject>

- (void)CCHSuspensionMenu:(CCHSuspensionMenu *)menu selectedItemForIndex:(NSInteger)index;

@end

@interface CCHSuspensionMenu : UIView

@property(nonatomic, assign)CGFloat menuSize;

@property(nonatomic, assign)CGFloat bothMargin;

@property(nonatomic, copy)NSArray<NSString *> *images;
@property(nonatomic, copy)NSArray<NSString *> *heightlightImages;
@property(nonatomic, copy)NSArray<NSString *> *titles;

@property(nonatomic, copy)NSArray<UIButton *> *menuBtns;

@property(nonatomic, weak)id<CCHSuspensionMenuDelegate> delegate;

- (instancetype)initWithPrimaryImage:(NSString *)primaryImage menuSize:(CGFloat)menuSize menuNum:(NSInteger)menuNum;


@end
