//
//  CCHSuspensionMenu.m
//  HJSupendMenu
//
//  Created by 陈灿和 on 2017/12/7.
//  Copyright © 2017年 陈灿和. All rights reserved.
//

#import "CCHSuspensionMenu.h"

#define CHHSuspensionMenuButtonMargin 5
#define CHHSuspensionMenuButtonTitleHeight 17

@interface CHHSuspensionMenuButton : UIButton
@property(nonatomic, assign)NSInteger index;
@end
@implementation CHHSuspensionMenuButton

- (CGRect)titleRectForContentRect:(CGRect)contentRect {
    CGFloat margin = CHHSuspensionMenuButtonMargin;
    CGFloat h = CHHSuspensionMenuButtonTitleHeight;
    return CGRectMake(0, contentRect.size.height - h - margin, contentRect.size.width, h);
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect {
    CGFloat margin = CHHSuspensionMenuButtonMargin;
    CGFloat h = CHHSuspensionMenuButtonTitleHeight;
    CGFloat mh = contentRect.size.height - h - margin*2;
    return CGRectMake(contentRect.size.width/2 - mh/2, margin, mh, mh);
}

@end

typedef enum : NSUInteger {
    directionLeftType,
    directionRightType,
    
} directionType;

@interface CCHSuspensionMenu()
@property(nonatomic, strong)UIButton *mBtn;
@property(nonatomic, assign)NSInteger menuNum;
@property(nonatomic, copy)NSString *primaryImage;
@property(nonatomic, strong)UIView *bar;

@property(nonatomic, assign)CGFloat barWidth;

@property(nonatomic, assign)CGFloat maxX;
@property(nonatomic, assign)CGFloat maxY;
@property(nonatomic, assign)CGFloat minX;
@property(nonatomic, assign)CGFloat minY;

@property(nonatomic, assign)BOOL isOpen;
@property(nonatomic, assign)BOOL isOpening;
@property(nonatomic, assign)BOOL isMove;
@property(nonatomic, assign)BOOL isVisible;

@property(nonatomic, assign)NSInteger countdownTime;
@property(nonatomic, assign)NSInteger currentTime;

@property(nonatomic, strong)NSTimer *timer;

@property(nonatomic, assign)directionType direction;


@end

@implementation CCHSuspensionMenu

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}

- (instancetype)initWithPrimaryImage:(NSString *)primaryImage menuSize:(CGFloat)menuSize menuNum:(NSInteger)menuNum
{
    self = [super initWithFrame:CGRectMake(0, 80, menuSize, menuSize)];
    if (self) {
        self.primaryImage = primaryImage;
        self.menuNum = menuNum;
        self.menuSize = menuSize;
        self.countdownTime = 2;//菜单栏关闭的情况下，主按钮显示过countdownTime后就隐身
        self.isVisible = YES;
        self.bothMargin = 3;

        [self setup];
    }
    return self;
}

- (void)willMoveToSuperview:(UIView *)newSuperview {
    if (newSuperview) {
        [newSuperview addSubview:self.bar];
    }
}

- (void)didMoveToSuperview {
    [self resetXY];//**重要，添加进父视图后设置xy，不然菜单会错位
}

- (void)resetXY {
    self.maxX = self.superview.frame.size.width;
    self.maxY = self.superview.frame.size.height;
    self.minX = 0;
    self.minY = 0;
}

- (void)screenChange {
    [self resetXY];
    [self visibleMenu];
    [self resetFrameMenu];
    [self adjustBtnFrame];
}


- (void)willRemoveSubview:(UIView *)subview {
    [self.timer invalidate];
    self.timer = nil;
}

- (void)setup {
    
    self.backgroundColor = [UIColor clearColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(screenChange) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
    
    
    self.timer = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(countdownShow) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    
    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(changePointAction:)];
    [self addGestureRecognizer:panGestureRecognizer];
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapPrimaryBtnAction:)];
    [self addGestureRecognizer:tapGestureRecognizer];

    UIButton *mbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:mbtn];
    mbtn.frame = CGRectMake(0, 0, _menuSize, _menuSize);
    mbtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [mbtn setImage:[UIImage imageNamed:self.primaryImage] forState:UIControlStateNormal];
    self.mBtn = mbtn;
    mbtn.userInteractionEnabled = NO;
    
    [self createMenuBarForBtns];

}

- (void)createMenuBarForBtns {
    
    [_bar removeFromSuperview];
    
    NSArray *btns = [self createMenuBtnsForNum:_menuNum];
    _menuBtns = btns;
    
    _barWidth = _menuSize*_menuNum + _bothMargin*(_menuNum- 1);
    
    UIView *bar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _barWidth, _menuSize)];
    _bar = bar;
    bar.layer.cornerRadius = _menuSize/2;
    bar.layer.masksToBounds = YES;
    bar.backgroundColor = [UIColor blackColor];
    bar.hidden = YES;
    
    for (int i = 0; i < _menuNum; i++) {
        CHHSuspensionMenuButton *btn = (CHHSuspensionMenuButton *)_menuBtns[i];
        [bar addSubview:btn];
        btn.frame = CGRectMake(i*(_menuSize) + (i)*_bothMargin, 0, _menuSize, _menuSize);
        btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        btn.titleLabel.textAlignment = NSTextAlignmentCenter;
        btn.titleLabel.font = [UIFont systemFontOfSize:11];
        btn.titleLabel.textColor = [UIColor whiteColor];
        btn.titleLabel.adjustsFontSizeToFitWidth = YES;
        btn.backgroundColor = [UIColor darkGrayColor];
        btn.layer.cornerRadius = _menuSize/2;
        btn.layer.masksToBounds = YES;
        [btn addTarget:self action:@selector(selectedItemAction:) forControlEvents:UIControlEventTouchUpInside];
        btn.index = i;
        
    }

}


- (void)selectedItemAction:(CHHSuspensionMenuButton *)sender {
    
    if ([self.delegate respondsToSelector:@selector(CCHSuspensionMenu:selectedItemForIndex:)]) {
        [self.delegate CCHSuspensionMenu:self selectedItemForIndex:sender.index];
    }
    
    [self hide];
}

- (void)show {
    
    if (self.isOpening) {
        return;
    }
    if (self.isOpen) {
        [self hide];
        return;
    };
    self.isOpening = YES;
    self.currentTime = 0;
    self.bar.hidden = NO;

    [self visibleMenu];
    
    [self adjustBtnFrame];
    
    self.bar.transform = CGAffineTransformMakeScale(0, 0);
    
    [UIView animateWithDuration:0.2 delay:0 usingSpringWithDamping:0.8 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.bar.transform = CGAffineTransformIdentity;
        
    } completion:^(BOOL finished) {
        self.isOpening = NO;
        self.bar.transform = CGAffineTransformIdentity;
        
    }];
    self.isOpen = YES;
}


- (void)hide {
    
    if (self.isOpening) {
        return;
    }
    if (self.isOpen == NO) {
        [self show];
        return;
    };
    
    self.isOpening = YES;
    self.bar.transform = CGAffineTransformIdentity;
    [UIView animateWithDuration:0.2 animations:^{
        self.bar.transform = CGAffineTransformMakeScale(0, 0);
    } completion:^(BOOL finished) {
        self.isOpening = NO;
        self.bar.hidden = YES;

        self.bar.transform = CGAffineTransformIdentity;
        [self setAnchorPoint:CGPointMake(0.5, 0.5) forView:self.bar];

    }];
    
    self.isOpen = NO;
}

- (NSArray *)createMenuBtnsForNum:(NSInteger)num {
    
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    for (int i = 0; i < num; i++) {
        UIButton *btn = [CHHSuspensionMenuButton buttonWithType:UIButtonTypeCustom];
        [arr addObject:btn];
    }
    return arr;
}

- (void)tapPrimaryBtnAction:(UITapGestureRecognizer *)tap {
    
    if (tap.state == UIGestureRecognizerStateEnded) {
        [self show];
    }

}

- (void)changePointAction:(UIPanGestureRecognizer *)pan {
    
    if (self.isOpen) {
        return;
    }
    switch (pan.state) {
        case UIGestureRecognizerStateBegan:
        {
            self.currentTime = 0;
    
            [UIView animateWithDuration:0.1 animations:^{
                [self visibleMenu];
            }];
        }
            break;
        case UIGestureRecognizerStateChanged:
        {
            self.isMove = YES;
            CGPoint point = [pan locationInView:self.superview];
            self.center = point;
            
            
        }
            break;
        case UIGestureRecognizerStateEnded:
        {
            if (self.isMove) {
                self.isMove = NO;
                [self resetFrameMenu];
            }
            
        }
            break;
        default:
            break;
    }
    
}

- (void)resetFrameMenu {
    CGRect rect = self.frame;
    
    if (self.frame.origin.x > (_maxX/2 - _menuSize/2)) {
        self.direction = directionRightType;
        rect.origin.x = (_maxX - _menuSize);
    } else {
        self.direction = directionLeftType;
        rect.origin.x = _minX;
    }
    if (self.frame.origin.y > (_maxY - _menuSize)) {
        rect.origin.y = (_maxY - _menuSize);
    }
    if (self.frame.origin.y < 0) {
        rect.origin.y = _minY;
    }
    
    [UIView animateWithDuration:0.1 animations:^{
        self.frame = rect;
    }];

}

- (void)countdownShow {
    
    if (self.isVisible == NO) {
        return;
    }
    
    if (self.isOpen) {
        self.currentTime = 0;
        return;
    }
    
    if (self.isMove) {
        self.currentTime = 0;
    } else {
        if (self.currentTime >= self.countdownTime) {
            self.currentTime = 0;
            //to do..
            [UIView animateWithDuration:0.1 animations:^{
                [self invisibleMenu];

            }];

        } else {
            self.currentTime += 1;
        }
    }
    
}

- (void)visibleMenu {
    self.isVisible = YES;
    self.mBtn.alpha = 1;
    self.transform = CGAffineTransformIdentity;
}

- (void)invisibleMenu {
    self.isVisible = NO;
    self.mBtn.alpha = 0.3;
    CGFloat translation = 0;
    if (self.direction == directionLeftType) {
        translation = -_menuSize/2;
    } else {
        translation = _menuSize/2;
    }
    self.transform = CGAffineTransformConcat(CGAffineTransformMakeRotation(M_PI/180*30), CGAffineTransformMakeTranslation(translation, 0));
}

- (void)setImages:(NSArray<NSString *> *)images {
    _images = images;
    [self adjustBtnContent];
    
}

- (void)setTitles:(NSArray<NSString *> *)titles {
    _titles = titles;
    [self adjustBtnContent];
    
}

- (void)setHeightlightImages:(NSArray<NSString *> *)heightlightImages {
    _heightlightImages = heightlightImages;
    [self adjustBtnContent];
}

- (void)adjustBtnContent {
    for (int i = 0; i < _menuNum; i++) {
        UIButton *btn = _menuBtns[i];
        NSString *image = nil;
        NSString *title = nil;
        NSString *heightlightImage = nil;
        UIImage *mImage;
        UIImage *mHeightlightImage;
        if (self.images) {
            image = self.images[i];
            mImage = [UIImage imageNamed:image];
            [btn setImage:mImage forState:UIControlStateNormal];
            
        }
        if (self.titles) {
            title = self.titles[i];
            [btn setTitle:title forState:UIControlStateNormal];
            
        }
        if (self.heightlightImages) {
            mHeightlightImage = [UIImage imageNamed:heightlightImage];
            [btn setImage:mHeightlightImage forState:UIControlStateHighlighted];
        }
        
    }
}


- (void)adjustBtnFrame {
    CGRect rect = self.frame;
    
    if (self.direction == directionLeftType) {
        self.bar.frame = CGRectMake(CGRectGetMaxX(rect) + _bothMargin, rect.origin.y, _barWidth, _menuSize);
        
    } else {
        self.bar.frame = CGRectMake(CGRectGetMinX(rect) - _bothMargin - _barWidth, rect.origin.y, _barWidth, _menuSize);
        
    }
    if (self.direction == directionLeftType) {
        [self setAnchorPoint:CGPointMake(0, 0.5) forView:self.bar];
        
    } else {
        [self setAnchorPoint:CGPointMake(1, 0.5) forView:self.bar];
    }
}

-(void)setAnchorPoint:(CGPoint)anchorPoint forView:(UIView *)view
{
    CGPoint newPoint = CGPointMake(view.bounds.size.width * anchorPoint.x,
                                   view.bounds.size.height * anchorPoint.y);
    CGPoint oldPoint = CGPointMake(view.bounds.size.width * view.layer.anchorPoint.x,
                                   view.bounds.size.height * view.layer.anchorPoint.y);
    
//    newPoint = CGPointApplyAffineTransform(newPoint, view.transform);
//    oldPoint = CGPointApplyAffineTransform(oldPoint, view.transform);
    
    CGPoint position = view.layer.position;
    
    position.x -= oldPoint.x;
    position.x += newPoint.x;
    
    position.y -= oldPoint.y;
    position.y += newPoint.y;
    
    view.center = position;
    view.layer.anchorPoint = anchorPoint;
}

@end
